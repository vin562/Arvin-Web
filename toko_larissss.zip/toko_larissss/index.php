<?php include 'database.php'; ?>
<?php
$totalBarang   = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM barang"))['c'] ?? 0;
$totalSupplier = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM supplier"))['c'] ?? 0;
$totalPembeli  = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM pembeli"))['c'] ?? 0;
$totalPembelian= mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM pembelian"))['c'] ?? 0;
$totalStok     = mysqli_fetch_assoc(mysqli_query($conn,"SELECT SUM(jumlah_barang) s FROM barang"))['s'] ?? 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sistem Toko Laris — Dashboard</title>
<link rel="stylesheet" href="style.css">
<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>

<?php include 'topbar.php'; ?>

<div class="page-wrap">
    <!-- HERO -->
    <div class="page-hero">
        <div class="page-hero-content">
            <h2><i class="fa-solid fa-hand-spock" style="color:yellow;"></i> Selamat datang Admin</h2>
            <p>Sistem Manajemen Toko Laris — Kelola barang, supplier, pembeli &amp; transaksi dengan mudah</p>
        </div>
    </div>

    <!-- STATS -->
    <div class="stats-row">
        <div class="stat-card red">
            <div class="stat-icon"><i class="fa-solid fa-box-open" style="color:brown;"></i></div>
            <div class="stat-info">
                <div class="val"><?= $totalBarang ?></div>
                <div class="lbl">Total Barang</div>
            </div>
        </div>
        <div class="stat-card gold">
            <div class="stat-icon"><i class="fa-solid fa-cubes" style="color:green;"></i></div>
            <div class="stat-info">
                <div class="val"><?= number_format($totalStok) ?></div>
                <div class="lbl">Total Stok</div>
            </div>
        </div>
        <div class="stat-card green">
            <div class="stat-icon"><i class="fa-solid fa-industry" style="color:black;"></i></div>
            <div class="stat-info">
                <div class="val"><?= $totalSupplier ?></div>
                <div class="lbl">Supplier Aktif</div>
            </div>
        </div>
        <div class="stat-card orange">
            <div class="stat-icon"><i class="fa-solid fa-users" style="color:black;"></i></div>
            <div class="stat-info">
                <div class="val"><?= $totalPembeli ?></div>
                <div class="lbl">Total Pembeli</div>
            </div>
        </div>
        <div class="stat-card" style="border-top-color:var(--r6);">
            <div class="stat-icon" style="background:var(--r1);"><i class="fa-solid fa-cart-plus" style="color:var(--r6);"></i></div>
            <div class="stat-info">
                <div class="val"><?= $totalPembelian ?></div>
                <div class="lbl">Total Transaksi</div>
            </div>
        </div>
    </div>

    <!-- CONTENT -->
    <div class="content" style="margin-top:24px;">
        <div class="welcome-grid">
            <a class="welcome-card" href="barang.php">
            <div class="wc-icon"><i class="fa-solid fa-box-open" style="color:brown;"></i></div>
                <h3>Kelola Barang</h3>
                <p>Tambah, edit, dan hapus data barang beserta stok</p>
            </a>
            <a class="welcome-card" href="supplier.php">
            <div class="wc-icon"><i class="fa-solid fa-industry" style="color:black;"></i></div>
                <h3>Kelola Supplier</h3>
                <p>Manajemen data pemasok &amp; mitra bisnis</p>
            </a>
            <a class="welcome-card" href="pembeli.php">
            <div class="wc-icon"><i class="fa-solid fa-users" style="color:green;"></i></div>
                <h3>Kelola Pembeli</h3>
                <p>Data pelanggan dan pembeli toko</p>
            </a>
            <a class="welcome-card" href="pembelian.php">
            <div class="wc-icon"><i class="fa-solid fa-cart-plus" style="color:black;"></i></div>
                <h3>Riwayat Pembelian</h3>
                <p>Lihat seluruh histori transaksi pembelian</p>
            </a>
        </div>
    </div>

    <footer class="site-footer">
        &copy; <?= date('Y') ?> <strong>Toko Laris</strong> — Sistem Manajemen Toko
    </footer>
</div>
</body>
</html>