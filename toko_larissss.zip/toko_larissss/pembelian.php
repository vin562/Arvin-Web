<?php include 'database.php'; ?>
<?php
/* ── GENERATE NO FRAKTUR OTOMATIS ── */
function generateFraktur($conn) {
    $prefix = 'FKT';
    $tanggal = date('Ymd');
    // Cek jumlah transaksi hari ini untuk nomor urut
    $count = mysqli_fetch_assoc(mysqli_query($conn, 
        "SELECT COUNT(*) c FROM pembelian WHERE DATE(tanggal_pembelian) = CURDATE()"))['c'] ?? 0;
    $urut = str_pad($count + 1, 3, '0', STR_PAD_LEFT);
    // Tambah random 2 digit untuk keunikan
    $random = str_pad(rand(0, 99), 2, '0', STR_PAD_LEFT);
    return $prefix . $tanggal . $urut . $random;
}

/* ── TAMBAH PEMBELIAN (HEADER + DETAIL) ── */
if (isset($_POST['create_pembelian'])) {
    $id_pembeli = intval($_POST['id_pembeli']);
    $tanggal    = mysqli_real_escape_string($conn, $_POST['tanggal']);
    // Generate no fraktur otomatis
    $no_fraktur = generateFraktur($conn);

    // Insert header pembelian
    mysqli_query($conn, "INSERT INTO pembelian (id_pembeli, tanggal_pembelian, no_fraktur) 
        VALUES ('$id_pembeli', '$tanggal', '$no_fraktur')");
    $id_pembelian = mysqli_insert_id($conn);

    // Insert detail pembelian (multiple items)
    if (isset($_POST['items']) && is_array($_POST['items'])) {
        foreach ($_POST['items'] as $item) {
            $kode_barang = intval($item['kode_barang']);
            $jumlah = intval($item['jumlah']);
            if ($kode_barang > 0 && $jumlah > 0) {
                mysqli_query($conn, "INSERT INTO detail_pembelian (id_pembelian, kode_barang, jumlah) 
                    VALUES ('$id_pembelian', '$kode_barang', '$jumlah')");
                // Kurangi stok barang
                mysqli_query($conn, "UPDATE barang SET jumlah_barang = jumlah_barang - $jumlah 
                    WHERE kode_barang = '$kode_barang'");
            }
        }
    }
    header("Location: pembelian.php?notif=created"); exit;
}

/* ── DELETE PEMBELIAN ── */
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    // Restore stok sebelum hapus
    $details = mysqli_query($conn, "SELECT kode_barang, jumlah FROM detail_pembelian WHERE id_pembelian='$id'");
    while ($d = mysqli_fetch_assoc($details)) {
        $kode = intval($d['kode_barang']);
        $jml = intval($d['jumlah']);
        mysqli_query($conn, "UPDATE barang SET jumlah_barang = jumlah_barang + $jml WHERE kode_barang='$kode'");
    }
    mysqli_query($conn, "DELETE FROM detail_pembelian WHERE id_pembelian='$id'");
    mysqli_query($conn, "DELETE FROM pembelian WHERE id_pembelian='$id'");
    header("Location: pembelian.php?notif=deleted"); exit;
}

/* ── STATS ── */
$total = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM pembelian"))['c'] ?? 0;
$hari  = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM pembelian WHERE DATE(tanggal_pembelian)=CURDATE()"))['c'] ?? 0;

/* ── GENERATE FRAKTUR UNTUK TAMPILAN ── */
$fraktur_otomatis = generateFraktur($conn);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pembelian — Toko Laris</title>
<link rel="stylesheet" href="style.css">
<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>

<?php include 'topbar.php'; ?>

<div class="page-wrap">
    <div class="page-hero">
        <div class="page-hero-content">
            <h2><i class="fa-solid fa-clipboard-list" style="color:black;"></i> Riwayat Pembelian</h2>
            <p>Histori seluruh transaksi pembelian barang dengan detail item</p>
        </div>
    </div>

    <div class="stats-row">
        <div class="stat-card orange">
            <div class="stat-icon"><i class="fa-solid fa-cart-plus" style="color:black;"></i></div>
            <div class="stat-info">
                <div class="val"><?= $total ?></div>
                <div class="lbl">Total Transaksi</div>
            </div>
        </div>
        <div class="stat-card green">
            <div class="stat-icon"><i class="fa-solid fa-calendar-days" style="color:black;"></i></div>
            <div class="stat-info">
                <div class="val"><?= $hari ?></div>
                <div class="lbl">Transaksi Hari Ini</div>
            </div>
        </div>
    </div>

    <div class="content" style="margin-top:24px;">

        <?php if (isset($_GET['notif'])): ?>
        <div class="alert <?= $_GET['notif'] === 'deleted' ? 'alert-danger' : 'alert-success' ?>">
            <?php
            $msgs = [
                'created' => '<i class="fa-solid fa-square-check" style="color:green;"></i> Transaksi pembelian berhasil dicatat!',
                'deleted' => '<i class="fa-solid fa-trash-can" style="color:black;"></i> Transaksi berhasil dihapus dan stok dikembalikan.',
            ];
            echo $msgs[$_GET['notif']] ?? 'Operasi berhasil.';
            ?>
        </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-head">
                <div class="card-head-left">
                    <div class="card-head-icon"><i class="fa-solid fa-clipboard-list" style="color:black;"></i></div>
                    <div>
                        <h3>Riwayat Transaksi</h3>
                        <p><?= $total ?> transaksi tercatat</p>
                    </div>
                </div>
                <div style="display:flex;gap:8px;">
                    <a href="pembeli.php" class="btn btn-outline btn-sm"><i class="fa-solid fa-users"></i> Data Pembeli</a>
                    <button class="btn btn-red" onclick="openModal('modal-tambah')">
                        <i class="fa-solid fa-square-plus" style="color:orange;"></i> Tambah Transaksi
                    </button>
                </div>
            </div>

            <div class="card-body card-body-np">
                <div style="padding:16px 24px 0;">
                    <div class="toolbar">
                        <div class="search-wrap">
                            <input type="text" id="cari" placeholder="Cari transaksi..." onkeyup="filterTbl()">
                        </div>
                    </div>
                </div>

                <div class="table-wrap">
                    <table id="tblPembelian">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>No. Faktur</th>
                                <th>Pembeli</th>
                                <th>Tanggal</th>
                                <th>Detail Barang</th>
                                <th>Total Item</th>
                                <th style="text-align:center;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        $data = mysqli_query($conn,"SELECT p.*, pb.nama_pembeli 
                            FROM pembelian p
                            LEFT JOIN pembeli pb ON p.id_pembeli = pb.id_pembeli
                            ORDER BY p.tanggal_pembelian DESC");
                        $no = 1;
                        $today = date('Y-m-d');
                        if ($data && mysqli_num_rows($data) > 0):
                            while ($d = mysqli_fetch_assoc($data)):
                                $isToday = date('Y-m-d', strtotime($d['tanggal_pembelian'])) === $today;
                                $id_pembelian = intval($d['id_pembelian']);

                                // Get detail items for this purchase
                                $details = mysqli_query($conn, "SELECT dp.*, b.nama_barang, b.kode_barang 
                                    FROM detail_pembelian dp
                                    JOIN barang b ON dp.kode_barang = b.kode_barang
                                    WHERE dp.id_pembelian = '$id_pembelian'");
                                $items = [];
                                $total_items = 0;
                                while ($det = mysqli_fetch_assoc($details)) {
                                    $items[] = $det;
                                    $total_items += intval($det['jumlah']);
                                }
                        ?>
                            <tr>
                                <td style="color:var(--gray-400);font-size:12px;"><?= $no++ ?></td>
                                <td class="td-kode">
                                    <span style="background:var(--red-100);color:var(--red-700);padding:3px 8px;border-radius:5px;font-size:12px;font-weight:700;">
                                        <?= htmlspecialchars($d['no_fraktur']) ?>
                                    </span>
                                </td>
                                <td><strong><?= htmlspecialchars($d['nama_pembeli'] ?? 'Umum') ?></strong></td>
                                <td>
                                    <div style="font-size:13px;">
                                        <?= date('d M Y', strtotime($d['tanggal_pembelian'])) ?>
                                    </div>
                                    <div style="font-size:11px;color:var(--gray-400);">
                                        <?= date('H:i', strtotime($d['tanggal_pembelian'])) ?> WIB
                                    </div>
                                    <?php if ($isToday): ?>
                                    <span class="badge badge-green" style="margin-top:4px;">
                                        <i class="fa-solid fa-circle" style="color:green;font-size:8px;"></i> Hari ini
                                    </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php foreach ($items as $item): ?>
                                    <div style="font-size:12px;margin-bottom:3px;">
                                        <span style="color:var(--red-600);font-weight:700;">•</span>
                                        <?= htmlspecialchars($item['nama_barang']) ?> 
                                        <span style="background:var(--gold-100);color:var(--gold-700);padding:1px 6px;border-radius:4px;font-size:11px;">
                                            x<?= $item['jumlah'] ?>
                                        </span>
                                    </div>
                                    <?php endforeach; ?>
                                    <?php if (empty($items)): ?>
                                    <span class="badge badge-gray">Tidak ada item</span>
                                    <?php endif; ?>
                                </td>
                                <td style="text-align:center;">
                                    <span style="font-size:18px;font-weight:800;color:var(--green);"><?= $total_items ?></span>
                                    <div style="font-size:11px;color:var(--gray-400);">unit</div>
                                </td>
                                <td style="text-align:center;">
                                    <div class="aksi" style="justify-content:center;">
                                        <a href="?delete=<?= $id_pembelian ?>"
                                           onclick="return confirm('Hapus transaksi ini? Stok akan dikembalikan.')"
                                           class="aksi-btn aksi-hapus">
                                           <i class="fa-solid fa-trash-can" style="color:black;"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile;
                        else: ?>
                            <tr><td colspan="7">
                                <div class="empty-state">
                                    <div class="empty-icon"><i class="fa-solid fa-file-circle-exclamation"></i></div>
                                    <h4>Belum ada transaksi</h4>
                                    <p>Klik "+ Tambah Transaksi" untuk mencatat pembelian baru.</p>
                                </div>
                            </td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <footer class="site-footer">
        &copy; <?= date('Y') ?> <strong>Toko Laris</strong>
    </footer>
</div>

<!-- ══ TAMBAH PEMBELIAN ══════════════════════════════════════ -->
<div class="modal-overlay" id="modal-tambah">
    <div class="modal-box" style="max-width:600px;">
        <div class="modal-head">
            <h3><i class="fa-solid fa-cart-plus" style="color:green;"></i> Tambah Transaksi Pembelian</h3>
            <button class="modal-close" onclick="closeModal('modal-tambah')"><i class="fa-solid fa-x" style="color:black;"></i></button>
        </div>
        <div class="modal-body">
            <form method="POST" id="form-pembelian">
                <div class="form-grid-2">
                    <div class="form-group">
                        <label>Pembeli <span>*</span></label>
                        <select class="form-ctrl" name="id_pembeli" required>
                            <option value="">-- Pilih Pembeli --</option>
                            <?php
                            $pembeli = mysqli_query($conn,"SELECT * FROM pembeli ORDER BY nama_pembeli");
                            while ($p = mysqli_fetch_assoc($pembeli)):
                            ?>
                            <option value="<?= $p['id_pembeli'] ?>"><?= htmlspecialchars($p['nama_pembeli']) ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>No. Fraktur <span style="color:var(--g4);font-weight:400;">(Otomatis)</span></label>
                        <div class="form-ctrl" style="background:var(--g1);font-family:'Nunito',monospace;font-weight:700;color:var(--r6);display:flex;align-items:center;gap:8px;">
                            <i class="fa-solid fa-lock" style="color:var(--g4);font-size:12px;"></i>
                            <?= $fraktur_otomatis ?>
                        </div>
                        <div style="font-size:11px;color:var(--g4);margin-top:4px;">
                            <i class="fa-solid fa-wand-magic-sparkles"></i> No. fraktur digenerate otomatis oleh sistem
                        </div>
                    </div>
                </div>
                <div class="form-grid-2">
                    <div class="form-group">
                        <label>Tanggal Pembelian <span>*</span></label>
                        <input class="form-ctrl" type="date" name="tanggal" value="<?= date('Y-m-d') ?>" required>
                    </div>
                </div>

                <hr style="margin:16px 0;border:none;border-top:1px solid var(--gray-200);">
                <h4 style="font-size:14px;margin-bottom:12px;color:var(--gray-700);">
                    <i class="fa-solid fa-box-open" style="color:brown;"></i> Item Barang
                </h4>

                <div id="items-container">
                    <div class="item-row" style="display:grid;grid-template-columns:2fr 1fr auto;gap:8px;margin-bottom:8px;align-items:end;">
                        <div class="form-group" style="margin-bottom:0;">
                            <label>Barang</label>
                            <select class="form-ctrl" name="items[0][kode_barang]" required>
                                <option value="">-- Pilih Barang --</option>
                                <?php
                                $brg = mysqli_query($conn,"SELECT * FROM barang WHERE jumlah_barang > 0 ORDER BY nama_barang");
                                while ($b = mysqli_fetch_assoc($brg)):
                                ?>
                                <option value="<?= $b['kode_barang'] ?>"><?= htmlspecialchars($b['nama_barang']) ?> (Stok: <?= $b['jumlah_barang'] ?>)</option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="form-group" style="margin-bottom:0;">
                            <label>Jumlah</label>
                            <input class="form-ctrl" type="number" name="items[0][jumlah]" min="1" value="1" required>
                        </div>
                        <button type="button" class="btn btn-danger" onclick="this.closest('.item-row').remove()" style="padding:8px 12px;">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </div>
                </div>

                <button type="button" class="btn btn-outline" onclick="addItem()" style="margin-top:8px;width:100%;">
                    <i class="fa-solid fa-plus"></i> Tambah Item Barang
                </button>

                <div class="form-footer" style="margin-top:16px;">
                    <button type="button" class="btn btn-ghost" onclick="closeModal('modal-tambah')">Batal</button>
                    <button name="create_pembelian" class="btn btn-red">
                        <i class="fa-solid fa-floppy-disk" style="color:green;"></i> Simpan Transaksi
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
let itemCount = 1;
function addItem() {
    const container = document.getElementById('items-container');
    const row = document.createElement('div');
    row.className = 'item-row';
    row.style.cssText = 'display:grid;grid-template-columns:2fr 1fr auto;gap:8px;margin-bottom:8px;align-items:end;';
    row.innerHTML = `
        <div class="form-group" style="margin-bottom:0;">
            <select class="form-ctrl" name="items[${itemCount}][kode_barang]" required>
                <option value="">-- Pilih Barang --</option>
                <?php
                $brg2 = mysqli_query($conn,"SELECT * FROM barang WHERE jumlah_barang > 0 ORDER BY nama_barang");
                while ($b2 = mysqli_fetch_assoc($brg2)):
                ?>
                <option value="<?= $b2['kode_barang'] ?>"><?= htmlspecialchars($b2['nama_barang']) ?> (Stok: <?= $b2['jumlah_barang'] ?>)</option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="form-group" style="margin-bottom:0;">
            <input class="form-ctrl" type="number" name="items[${itemCount}][jumlah]" min="1" value="1" required>
        </div>
        <button type="button" class="btn btn-danger" onclick="this.closest('.item-row').remove()" style="padding:8px 12px;">
            <i class="fa-solid fa-trash"></i>
        </button>
    `;
    container.appendChild(row);
    itemCount++;
}

function openModal(id) {
    document.getElementById(id).classList.add('open');
}
function closeModal(id) {
    document.getElementById(id).classList.remove('open');
}
document.querySelectorAll('.modal-overlay').forEach(el => {
    el.addEventListener('click', function(e) {
        if (e.target === this) this.classList.remove('open');
    });
});

function filterTbl() {
    const q = document.getElementById('cari').value.toLowerCase();
    document.querySelectorAll('#tblPembelian tbody tr').forEach(tr => {
        tr.style.display = tr.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
}
</script>
</body>
</html>