<?php include 'database.php'; ?>
<?php
/* ── GENERATE ID SUPPLIER ACAK ── */
function generateSupplierId($conn) {
    do {
        // Generate 6 digit angka acak
        $id = rand(100000, 999999);
        $cek = mysqli_query($conn, "SELECT id_supplier FROM supplier WHERE id_supplier='$id'");
    } while (mysqli_num_rows($cek) > 0);
    return $id;
}

/* ── CREATE ── */
if (isset($_POST['create'])) {
    $id = generateSupplierId($conn);
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $nama_pt = mysqli_real_escape_string($conn, $_POST['nama_pt']);
    mysqli_query($conn, "INSERT INTO supplier (id_supplier, nama_supplier, nama_pt) VALUES ('$id', '$nama', '$nama_pt')");
    header("Location: supplier.php?notif=created"); exit;
}

/* ── UPDATE ── */
if (isset($_GET['update'])) {
    $id = intval($_GET['update']);
    $nama = mysqli_real_escape_string($conn, $_GET['nama']);
    $nama_pt = mysqli_real_escape_string($conn, $_GET['nama_pt']);
    mysqli_query($conn, "UPDATE supplier SET nama_supplier='$nama', nama_pt='$nama_pt' WHERE id_supplier='$id'");
    header("Location: supplier.php?notif=updated"); exit;
}

/* ── DELETE ── */
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    mysqli_query($conn, "DELETE FROM supplier WHERE id_supplier='$id'");
    header("Location: supplier.php?notif=deleted"); exit;
}

/* ── STATS ── */
$total = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM supplier"))['c'] ?? 0;
$ptCount = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM supplier WHERE nama_pt LIKE 'PT%'"))['c'] ?? 0;
$cvCount = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM supplier WHERE nama_pt LIKE 'CV%'"))['c'] ?? 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Supplier — Toko Laris</title>
<link rel="stylesheet" href="style.css">
<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>

<?php include 'topbar.php'; ?>

<div class="page-wrap">
    <div class="page-hero">
        <div class="page-hero-content">
            <h2><i class="fa-solid fa-industry"></i> Data Supplier</h2>
            <p>Kelola data pemasok dan mitra bisnis toko Anda</p>
        </div>
    </div>

    <div class="stats-row">
        <div class="stat-card green">
            <div class="stat-icon"><i class="fa-solid fa-industry"></i></div>
            <div class="stat-info">
                <div class="val"><?= $total ?></div>
                <div class="lbl">Total Supplier</div>
            </div>
        </div>
        <div class="stat-card" style="border-top-color:#1e40af;">
            <div class="stat-icon" style="background:#dbeafe;"><i class="fa-solid fa-building" style="color:#1e40af;"></i></div>
            <div class="stat-info">
                <div class="val" style="color:#1e40af;"><?= $ptCount ?></div>
                <div class="lbl">Bentuk PT</div>
            </div>
        </div>
        <div class="stat-card" style="border-top-color:#7c3aed;">
            <div class="stat-icon" style="background:#ede9fe;"><i class="fa-solid fa-handshake" style="color:#7c3aed;"></i></div>
            <div class="stat-info">
                <div class="val" style="color:#7c3aed;"><?= $cvCount ?></div>
                <div class="lbl">Bentuk CV</div>
            </div>
        </div>
    </div>

    <div class="content" style="margin-top:24px;">
        <?php if (isset($_GET['notif'])): ?>
        <div class="alert <?= $_GET['notif']==='deleted' ? 'alert-danger' : 'alert-success' ?>">
            <?php
            $msgs = [
                'created' => '<i class="fa-solid fa-square-check"></i> Supplier berhasil ditambahkan!',
                'updated' => '<i class="fa-solid fa-pen"></i> Supplier berhasil diperbarui!',
                'deleted' => '🗑️ Supplier berhasil dihapus.'
            ];
            echo $msgs[$_GET['notif']] ?? 'Operasi berhasil.';
            ?>
        </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-head">
                <div class="card-head-left">
                    <div class="card-head-icon"><i class="fa-solid fa-industry"></i></div>
                    <div>
                        <h3>Daftar Supplier</h3>
                        <p><?= $total ?> supplier terdaftar</p>
                    </div>
                </div>
                <button class="btn btn-red" onclick="openModal('modal-tambah')">
                    <i class="fa-solid fa-square-plus"></i> Tambah Supplier
                </button>
            </div>

            <div class="card-body card-body-np">
                <div style="padding:16px 24px 0;">
                    <div class="toolbar">
                        <div class="search-wrap">
                            <input type="text" id="cari" placeholder="Cari supplier..." onkeyup="filterTbl()">
                        </div>
                    </div>
                </div>
                <div class="table-wrap">
                    <table id="tblSupplier">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>ID</th>
                                <th>Bentuk Usaha</th>
                                <th>Nama Supplier</th>
                                <th style="text-align:center;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        $data = mysqli_query($conn,"SELECT * FROM supplier ORDER BY nama_supplier");
                        $no   = 1;
                        if ($data && mysqli_num_rows($data) > 0):
                            while ($d = mysqli_fetch_assoc($data)):
                                $nama_pt = strtoupper(trim($d['nama_pt'] ?? ''));
                                $prefix = '';
                                $badgeColor = ['bg'=>'#f3f4f6','color'=>'#4b5563','icon'=>'fa-ellipsis'];
                                if (strpos($nama_pt, 'PT ') === 0) {
                                    $prefix = 'PT';
                                    $badgeColor = ['bg'=>'#dbeafe','color'=>'#1e40af','icon'=>'fa-building'];
                                } elseif (strpos($nama_pt, 'CV ') === 0) {
                                    $prefix = 'CV';
                                    $badgeColor = ['bg'=>'#ede9fe','color'=>'#7c3aed','icon'=>'fa-handshake'];
                                } elseif (strpos($nama_pt, 'UD ') === 0) {
                                    $prefix = 'UD';
                                    $badgeColor = ['bg'=>'#dcfce7','color'=>'#15803d','icon'=>'fa-store'];
                                } else {
                                    $prefix = 'LAINNYA';
                                }
                        ?>
                            <tr>
                                <td style="color:var(--g4);font-size:12px;"><?= $no++ ?></td>
                                <td class="td-kode">#<?= $d['id_supplier'] ?></td>
                                <td>
                                    <span style="display:inline-flex;align-items:center;gap:4px;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;background:<?= $badgeColor['bg'] ?>;color:<?= $badgeColor['color'] ?>;">
                                        <i class="fa-solid <?= $badgeColor['icon'] ?>"></i> <?= $prefix ?>
                                    </span>
                                </td>
                                <td>
                                    <div style="display:flex;align-items:center;gap:10px;">
                                        <div style="width:36px;height:36px;border-radius:50%;background:var(--r1);
                                            display:flex;align-items:center;justify-content:center;
                                            font-weight:800;color:var(--r6);font-size:14px;">
                                            <?= strtoupper(substr($d['nama_supplier'],0,1)) ?>
                                        </div>
                                        <div>
                                            <strong><?= htmlspecialchars($d['nama_supplier']) ?></strong>
                                            <?php if ($d['nama_pt']): ?>
                                            <div style="font-size:11px;color:var(--g4);"><?= htmlspecialchars($d['nama_pt']) ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td style="text-align:center;">
                                    <div class="aksi" style="justify-content:center;">
                                        <button class="aksi-btn aksi-edit" onclick="openEdit('<?= htmlspecialchars(json_encode($d), ENT_QUOTES) ?>')">
                                            <i class="fa-solid fa-pen"></i> Edit
                                        </button>
                                        <a href="?delete=<?= $d['id_supplier'] ?>"
                                           onclick="return confirm('Hapus supplier ini?')"
                                           class="aksi-btn aksi-hapus"><i class="fa-solid fa-trash-can"></i> Hapus</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile;
                        else: ?>
                            <tr><td colspan="5">
                                <div class="empty-state">
                                    <div class="empty-icon"><i class="fa-solid fa-industry"></i></div>
                                    <h4>Belum ada supplier</h4>
                                    <p>Tambahkan data supplier terlebih dahulu.</p>
                                </div>
                            </td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <footer class="site-footer">
        &copy; <?= date('Y') ?> <strong>Toko Laris</strong>
    </footer>
</div>

<!-- ══ TAMBAH SUPPLIER ══════════════════════════════════════ -->
<div class="modal-overlay" id="modal-tambah">
    <div class="modal-box">
        <div class="modal-head">
            <h3><i class="fa-solid fa-industry"></i> Tambah Supplier Baru</h3>
            <button class="modal-close" onclick="closeModal('modal-tambah')"><i class="fa-solid fa-x"></i></button>
        </div>
        <div class="modal-body">
            <form method="POST">
                <div class="form-group">
                    <label>ID Supplier <span style="color:var(--g4);font-weight:400;">(Otomatis)</span></label>
                    <div class="form-ctrl" style="background:var(--g1);font-family:'Nunito',monospace;font-weight:700;color:var(--r6);display:flex;align-items:center;gap:8px;">
                        <i class="fa-solid fa-lock" style="color:var(--g4);font-size:12px;"></i>
                        <?= generateSupplierId($conn) ?>
                    </div>
                    <div style="font-size:11px;color:var(--g4);margin-top:4px;">
                        <i class="fa-solid fa-wand-magic-sparkles"></i> ID digenerate otomatis oleh sistem
                    </div>
                </div>
                <div class="form-group">
                    <label>Nama Supplier <span>*</span></label>
                    <input class="form-ctrl" name="nama" placeholder="Contoh: Sumber Makmur" required>
                </div>
                <div class="form-group">
                    <label>Nama Perusahaan (Bentuk Usaha) <span>*</span></label>
                    <input class="form-ctrl" name="nama_pt" placeholder="Contoh: PT Sumber Makmur Jaya / CV Jaya Abadi / UD Berkah" required>
                    <div style="font-size:11px;color:var(--g4);margin-top:4px;">
                        <i class="fa-solid fa-circle-info"></i> Tulis lengkap dengan bentuk usaha: PT, CV, UD, dll
                    </div>
                </div>
                <div class="form-footer">
                    <button type="button" class="btn btn-ghost" onclick="closeModal('modal-tambah')">Batal</button>
                    <button name="create" class="btn btn-red"><i class="fa-solid fa-floppy-disk"></i> Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ══ EDIT SUPPLIER ══════════════════════════════════════ -->
<div class="modal-overlay" id="modal-edit">
    <div class="modal-box">
        <div class="modal-head">
            <h3><i class="fa-solid fa-pen"></i> Edit Data Supplier</h3>
            <button class="modal-close" onclick="closeModal('modal-edit')"><i class="fa-solid fa-x"></i></button>
        </div>
        <div class="modal-body">
            <form id="form-edit" method="GET">
                <input type="hidden" name="update" id="edit-id">
                <div class="form-group">
                    <label>ID Supplier</label>
                    <div class="form-ctrl" style="background:var(--g1);font-family:'Nunito',monospace;font-weight:700;color:var(--r6);display:flex;align-items:center;gap:8px;">
                        <i class="fa-solid fa-lock" style="color:var(--g4);font-size:12px;"></i>
                        <span id="edit-id-display"></span>
                    </div>
                </div>
                <div class="form-group">
                    <label>Nama Supplier <span>*</span></label>
                    <input class="form-ctrl" type="text" name="nama" id="edit-nama" required>
                </div>
                <div class="form-group">
                    <label>Nama Perusahaan (Bentuk Usaha) <span>*</span></label>
                    <input class="form-ctrl" type="text" name="nama_pt" id="edit-nama-pt" required>
                    <div style="font-size:11px;color:var(--g4);margin-top:4px;">
                        <i class="fa-solid fa-circle-info"></i> Tulis lengkap dengan bentuk usaha: PT, CV, UD, dll
                    </div>
                </div>
                <div class="form-footer">
                    <button type="button" class="btn btn-ghost" onclick="closeModal('modal-edit')">Batal</button>
                    <button type="submit" class="btn btn-gold"><i class="fa-solid fa-floppy-disk"></i> Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openModal(id) {
    document.getElementById(id).classList.add('open');
}
function closeModal(id) {
    document.getElementById(id).classList.remove('open');
}
document.querySelectorAll('.modal-overlay').forEach(el => {
    el.addEventListener('click', function(e) {
        if (e.target === this) this.classList.remove('open');
    });
});

function openEdit(json) {
    const d = JSON.parse(json);
    document.getElementById('edit-id').value = d.id_supplier;
    document.getElementById('edit-id-display').textContent = '#' + d.id_supplier;
    document.getElementById('edit-nama').value = d.nama_supplier;
    document.getElementById('edit-nama-pt').value = d.nama_pt || '';
    openModal('modal-edit');
}

function filterTbl() {
    const q = document.getElementById('cari').value.toLowerCase();
    document.querySelectorAll('#tblSupplier tbody tr').forEach(tr => {
        tr.style.display = tr.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
}
</script>
</body>
</html>