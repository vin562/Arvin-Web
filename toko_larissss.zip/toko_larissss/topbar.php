<?php
$current = basename($_SERVER['PHP_SELF']);
function navActive($file) {
    global $current;
    return $current === $file ? 'active' : '';
}
?>
<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="styletopbar.css">
<header class="topbar">
    <a class="topbar-brand" href="index.php">
        <div class="brand-logo"><i class="fa-solid fa-shop"></i></div>
        <div class="brand-text">
            <h1>TOKO LARIS</h1>
            <span>Sistem Manajemen Toko</span>
        </div>
    </a>

    <nav class="topbar-nav">
        <a href="index.php" class="<?= navActive('index.php') ?>">
            <span class="nav-icon"><i class="fa-solid fa-shop"></i></span> Dashboard
        </a>
        <a href="barang.php" class="<?= navActive('barang.php') ?>">
            <span class="nav-icon"><i class="fa-solid fa-box-open" style="color:brown;"></i></span> Barang
        </a>
        <a href="supplier.php" class="<?= navActive('supplier.php') ?>">
            <span class="nav-icon"><i class="fa-solid fa-industry" style="color:black;"></i></span> Supplier
        </a>
        <a href="pembeli.php" class="<?= navActive('pembeli.php') ?>">
            <span class="nav-icon"><i class="fa-solid fa-users" style="color:black;"></i></span> Pembeli
        </a>
        <a href="pembelian.php" class="<?= navActive('pembelian.php') ?>">
            <span class="nav-icon"><i class="fa-solid fa-cart-plus" style="color:black;"></i></span> Pembelian
        </a>
    </nav>

    <div class="topbar-right">
        <span class="topbar-date"><i class="fa-solid fa-calendar-days"></i> <?= date('d M Y') ?></span>
        <!-- USER DROPDOWN (tambahkan di dalam <div class="topbar-right"> atau area kanan navbar) -->
<div class="user-drop" id="userDrop">
    <div class="user-avatar-btn" onclick="toggleUser()">A</div>
    <div class="user-panel">
        <div class="user-panel-header">
            <div class="u-name">Admin</div>
        </div>
        <button class="user-panel-btn" onclick="doLogout()">
            <i class="fa-solid fa-right-from-bracket"></i> Logout
        </button>
    </div>
</div>

<script>
function toggleUser() {
    document.getElementById('userDrop').classList.toggle('open');
}
document.addEventListener('click', function(e) {
    const drop = document.getElementById('userDrop');
    if (!drop.contains(e.target)) drop.classList.remove('open');
});
function doLogout() {
    if (confirm('Yakin ingin logout?')) {
        window.location.href = 'loginuas.php';
    }
}
</script>
    </div>
</header>