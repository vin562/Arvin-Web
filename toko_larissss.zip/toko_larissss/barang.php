<?php include 'database.php'; ?>
<?php
/* ── GENERATE KODE BARANG ACAK ── */
function generateKodeBarang($conn) {
    do {
        // Generate angka acak 6 digit (100000 - 999999)
        $kode = rand(100000, 999999);
        $cek = mysqli_query($conn, "SELECT kode_barang FROM barang WHERE kode_barang='$kode'");
    } while ($cek && mysqli_num_rows($cek) > 0);
    return $kode;
}

/* ── CREATE ── */
if (isset($_POST['create'])) {
    $kode     = intval($_POST['kode_barang']);
    $nama     = mysqli_real_escape_string($conn, $_POST['nama']);
    $jenis    = mysqli_real_escape_string($conn, $_POST['jenis']);
    $tgl      = mysqli_real_escape_string($conn, $_POST['tgl']);
    $jumlah   = intval($_POST['jumlah']);
    $supplier = intval($_POST['supplier']);
    mysqli_query($conn, "INSERT INTO barang (kode_barang,nama_barang,jenis_barang,tanggal_kadaluarsa,jumlah_barang,id_supplier)
        VALUES ('$kode','$nama','$jenis','$tgl','$jumlah','$supplier')");
    header("Location: barang.php?notif=created"); exit;
}

/* ── UPDATE ── */
if (isset($_GET['update'])) {
    $kode     = intval($_GET['update']);
    $nama     = mysqli_real_escape_string($conn, $_GET['nama']);
    $jenis    = mysqli_real_escape_string($conn, $_GET['jenis']);
    $tgl      = mysqli_real_escape_string($conn, $_GET['tgl']);
    $jumlah   = intval($_GET['jumlah']);
    $supplier = intval($_GET['supplier']);
    mysqli_query($conn, "UPDATE barang SET nama_barang='$nama',jenis_barang='$jenis',
        tanggal_kadaluarsa='$tgl',jumlah_barang='$jumlah',id_supplier='$supplier'
        WHERE kode_barang='$kode'");
    header("Location: barang.php?notif=updated"); exit;
}

/* ── DELETE ── */
if (isset($_GET['delete'])) {
    $kode = intval($_GET['delete']);
    mysqli_query($conn, "DELETE FROM barang WHERE kode_barang='$kode'");
    header("Location: barang.php?notif=deleted"); exit;
}

/* ── STATS ── */
$totalBarang = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM barang"))['c'] ?? 0;
$totalStok   = mysqli_fetch_assoc(mysqli_query($conn,"SELECT SUM(jumlah_barang) s FROM barang"))['s'] ?? 0;
$maxStok     = mysqli_fetch_assoc(mysqli_query($conn,"SELECT MAX(jumlah_barang) m FROM barang"))['m'] ?? 1;

/* ── GENERATE KODE BARANG UNTUK FORM ── */
$kode_otomatis = generateKodeBarang($conn);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Data Barang — Toko Laris</title>
<link rel="stylesheet" href="style.css">
<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>

<?php include 'topbar.php'; ?>

<div class="page-wrap">

    <!-- HERO -->
    <div class="page-hero">
        <div class="page-hero-content">
            <h2><i class="fa-solid fa-box-open" style="color:brown;"></i> Data Barang</h2>
            <p>Kelola seluruh inventaris barang toko Anda</p>
        </div>
    </div>

    <!-- STATS -->
    <div class="stats-row">
        <div class="stat-card red">
            <div class="stat-icon"><i class="fa-solid fa-box-open" style="color:brown;"></i></div>
            <div class="stat-info">
                <div class="val"><?= $totalBarang ?></div>
                <div class="lbl">Jenis Barang</div>
            </div>
        </div>
        <div class="stat-card gold">
            <div class="stat-icon"><i class="fa-solid fa-cubes" style="color:green;"></i></div>
            <div class="stat-info">
                <div class="val"><?= number_format($totalStok) ?></div>
                <div class="lbl">Total Unit Stok</div>
            </div>
        </div>
    </div>

    <!-- CONTENT -->
    <div class="content" style="margin-top:24px;">

        <!-- NOTIF -->
        <?php if (isset($_GET['notif'])): ?>
        <div class="alert <?= $_GET['notif'] === 'deleted' ? 'alert-danger' : 'alert-success' ?>">
            <?php
            $msgs = [
                'created'    => '<i class="fa-solid fa-square-check" style="color:green;"></i> Barang berhasil ditambahkan!',
                'updated'    => '<i class="fa-solid fa-pen" style="color:orange;"></i> Data barang berhasil diperbarui!',
                'deleted'    => '<i class="fa-solid fa-trash-can" style="color:black;"></i> Barang berhasil dihapus.',
            ];
            echo $msgs[$_GET['notif']] ?? 'Operasi berhasil.';
            ?>
        </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-head">
                <div class="card-head-left">
                    <div class="card-head-icon"><i class="fa-solid fa-box-open" style="color:brown;"></i></div>
                    <div>
                        <h3>Daftar Barang</h3>
                        <p><?= $totalBarang ?> jenis barang terdaftar</p>
                    </div>
                </div>
                <button class="btn btn-red" onclick="openModal('modal-tambah')">
                    <i class="fa-solid fa-square-plus" style="color:orange;"></i> Tambah Barang
                </button>
            </div>

            <div class="card-body card-body-np">
                <div style="padding:16px 24px 0;">
                    <div class="toolbar">
                        <div class="search-wrap">
                            <input type="text" id="cari" placeholder="Cari barang..." onkeyup="filterBarang()">
                        </div>
                    </div>
                </div>

                <div class="table-wrap">
                    <table id="tblBarang">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kode</th>
                                <th>Nama Barang</th>
                                <th>Jenis</th>
                                <th>Supplier</th>
                                <th>Stok</th>
                                <th>Kadaluarsa</th>
                                <th style="text-align:center;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        $data = mysqli_query($conn, "SELECT b.*,s.nama_supplier FROM barang b
                            LEFT JOIN supplier s ON b.id_supplier=s.id_supplier
                            ORDER BY b.kode_barang");
                        $no = 1;
                        if ($data && mysqli_num_rows($data) > 0):
                            while ($d = mysqli_fetch_assoc($data)):
                                $stok  = intval($d['jumlah_barang']);
                                $pct   = $maxStok > 0 ? min(100, round($stok / $maxStok * 100)) : 0;
                                $cls   = $stok <= 5 ? 'low' : ($stok <= 20 ? 'mid' : 'high');
                                $today = date('Y-m-d');
                                $exp   = $d['tanggal_kadaluarsa'];
                                $isExp = $exp && $exp < $today;
                        ?>
                            <tr>
                                <td style="color:var(--g4);font-size:12px;"><?= $no++ ?></td>
                                <td class="td-kode"><?= htmlspecialchars($d['kode_barang']) ?></td>
                                <td><strong><?= htmlspecialchars($d['nama_barang']) ?></strong></td>
                                <td><span class="badge badge-red"><?= htmlspecialchars($d['jenis_barang']) ?></span></td>
                                <td><?= htmlspecialchars($d['nama_supplier'] ?? '-') ?></td>
                                <td>
                                    <div class="stok-bar">
                                        <span class="stok-num"><?= $stok ?></span>
                                        <div class="stok-progress">
                                            <div class="stok-fill <?= $cls ?>" style="width:<?= $pct ?>%"></div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <?php if ($exp): ?>
                                    <span class="badge <?= $isExp ? 'badge-orange' : 'badge-green' ?>">
                                        <?= $isExp ? '<i class="fa-solid fa-triangle-exclamation" style="color:red;"></i>' : '<i class="fa-solid fa-square-check" style="color:green;"></i>' ?> <?= date('d/m/Y', strtotime($exp)) ?>
                                    </span>
                                    <?php else: ?><span class="badge badge-gray">—</span><?php endif; ?>
                                </td>
                                <td>
                                    <div class="aksi" style="justify-content:center;">
                                        <button class="aksi-btn aksi-edit"
                                            onclick="openEdit('<?= htmlspecialchars(json_encode($d), ENT_QUOTES) ?>')">
                                            <i class="fa-solid fa-pen" style="color:orange;"></i> Edit
                                        </button>
                                        <a href="?delete=<?= $d['kode_barang'] ?>"
                                           onclick="return confirm('Hapus barang ini?')"
                                           class="aksi-btn aksi-hapus"><i class="fa-solid fa-trash-can" style="color:black;"></i></a>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile;
                        else: ?>
                            <tr><td colspan="8">
                                <div class="empty-state">
                                    <div class="empty-icon"><i class="fa-solid fa-dropbox" style="color:black;"></i></div>
                                    <h4>Belum ada barang</h4>
                                    <p>Klik "+ Tambah Barang" untuk mulai mengisi data.</p>
                                </div>
                            </td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <footer class="site-footer">
        &copy; <?= date('Y') ?> <strong>Toko Laris</strong>
    </footer>
</div>

<!-- ══ TAMBAH BARANG ══════════════════════════════════════ -->
<div class="modal-overlay" id="modal-tambah">
    <div class="modal-box">
        <div class="modal-head">
            <h3><i class="fa-solid fa-cart-plus" style="color:green;"></i> Tambah Barang Baru</h3>
            <button class="modal-close" onclick="closeModal('modal-tambah')"><i class="fa-solid fa-x" style="color:black;"></i></button>
        </div>
        <div class="modal-body">
            <form method="POST">
                <!-- HIDDEN INPUT: kode barang otomatis -->
                <input type="hidden" name="kode_barang" value="<?= $kode_otomatis ?>">

                <div class="form-group">
                    <label>Kode Barang <span style="color:var(--g4);font-weight:400;">(Otomatis)</span></label>
                    <div class="form-ctrl" style="background:var(--g1);font-family:'Nunito',monospace;font-weight:700;color:var(--r6);display:flex;align-items:center;gap:8px;">
                        <i class="fa-solid fa-lock" style="color:var(--g4);font-size:12px;"></i>
                        <?= $kode_otomatis ?>
                    </div>
                    <div style="font-size:11px;color:var(--g4);margin-top:4px;">
                        <i class="fa-solid fa-wand-magic-sparkles"></i> Kode digenerate otomatis oleh sistem
                    </div>
                </div>
                <div class="form-grid-2">
                    <div class="form-group">
                        <label>Nama Barang <span>*</span></label>
                        <input class="form-ctrl" type="text" name="nama" placeholder="Nama lengkap barang" required>
                    </div>
                    <div class="form-group">
                        <label>Jenis Barang</label>
                        <input class="form-ctrl" type="text" name="jenis" placeholder="Contoh: Sembako">
                    </div>
                </div>
                <div class="form-grid-2">
                    <div class="form-group">
                        <label>Supplier</label>
                        <select class="form-ctrl" name="supplier">
                            <option value="">-- Pilih Supplier --</option>
                            <?php
                            $supp = mysqli_query($conn,"SELECT * FROM supplier ORDER BY nama_supplier");
                            while ($x = mysqli_fetch_assoc($supp)):
                            ?>
                            <option value="<?= $x['id_supplier'] ?>"><?= htmlspecialchars($x['nama_supplier']) ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Jumlah Stok <span>*</span></label>
                        <input class="form-ctrl" type="number" name="jumlah" min="0" placeholder="0" required>
                    </div>
                </div>
                <div class="form-group">
                    <label>Tanggal Kadaluarsa</label>
                    <input class="form-ctrl" type="date" name="tgl">
                </div>
                <div class="form-footer">
                    <button type="button" class="btn btn-ghost" onclick="closeModal('modal-tambah')">Batal</button>
                    <button name="create" class="btn btn-red"><i class="fa-solid fa-floppy-disk" style="color:green;"></i> Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ══ EDIT BARANG ══════════════════════════════════════ -->
<div class="modal-overlay" id="modal-edit">
    <div class="modal-box">
        <div class="modal-head">
            <h3><i class="fa-solid fa-pen" style="color:orange;"></i> Edit Data Barang</h3>
            <button class="modal-close" onclick="closeModal('modal-edit')"><i class="fa-solid fa-x" style="color:black;"></i></button>
        </div>
        <div class="modal-body">
            <form id="form-edit" method="GET">
                <input type="hidden" name="update" id="edit-kode">
                <div class="form-group">
                    <label>Kode Barang</label>
                    <div class="form-ctrl" style="background:var(--g1);font-family:'Nunito',monospace;font-weight:700;color:var(--r6);display:flex;align-items:center;gap:8px;">
                        <i class="fa-solid fa-lock" style="color:var(--g4);font-size:12px;"></i>
                        <span id="edit-kode-display"></span>
                    </div>
                </div>
                <div class="form-grid-2">
                    <div class="form-group">
                        <label>Nama Barang <span>*</span></label>
                        <input class="form-ctrl" type="text" name="nama" id="edit-nama" required>
                    </div>
                    <div class="form-group">
                        <label>Jenis</label>
                        <input class="form-ctrl" type="text" name="jenis" id="edit-jenis">
                    </div>
                </div>
                <div class="form-grid-2">
                    <div class="form-group">
                        <label>Supplier</label>
                        <select class="form-ctrl" name="supplier" id="edit-supplier">
                            <?php
                            $supp2 = mysqli_query($conn,"SELECT * FROM supplier ORDER BY nama_supplier");
                            while ($x = mysqli_fetch_assoc($supp2)):
                            ?>
                            <option value="<?= $x['id_supplier'] ?>"><?= htmlspecialchars($x['nama_supplier']) ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Jumlah Stok</label>
                        <input class="form-ctrl" type="number" name="jumlah" id="edit-jumlah" min="0">
                    </div>
                </div>
                <div class="form-group">
                    <label>Tanggal Kadaluarsa</label>
                    <input class="form-ctrl" type="date" name="tgl" id="edit-tgl">
                </div>
                <div class="form-footer">
                    <button type="button" class="btn btn-ghost" onclick="closeModal('modal-edit')">Batal</button>
                    <button type="submit" class="btn btn-gold"><i class="fa-solid fa-floppy-disk" style="color:black;"></i> Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openModal(id) {
    document.getElementById(id).classList.add('open');
}
function closeModal(id) {
    document.getElementById(id).classList.remove('open');
}
// Close on backdrop click
document.querySelectorAll('.modal-overlay').forEach(el => {
    el.addEventListener('click', function(e) {
        if (e.target === this) this.classList.remove('open');
    });
});

function openEdit(json) {
    const d = JSON.parse(json);
    document.getElementById('edit-kode').value = d.kode_barang;
    document.getElementById('edit-kode-display').textContent = d.kode_barang;
    document.getElementById('edit-nama').value = d.nama_barang;
    document.getElementById('edit-jenis').value = d.jenis_barang;
    document.getElementById('edit-jumlah').value = d.jumlah_barang;
    document.getElementById('edit-tgl').value = d.tanggal_kadaluarsa;
    const sel = document.getElementById('edit-supplier');
    for (let o of sel.options) {
        if (o.value == d.id_supplier) { o.selected = true; break; }
    }
    openModal('modal-edit');
}

function filterBarang() {
    const q = document.getElementById('cari').value.toLowerCase();
    document.querySelectorAll('#tblBarang tbody tr').forEach(tr => {
        tr.style.display = tr.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
}
</script>
</body>
</html>