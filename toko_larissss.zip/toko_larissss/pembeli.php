<?php include 'database.php'; ?>
<?php
/* ── GENERATE ID PEMBELI ACAK ── */
function generatePembeliId($conn) {
    do {
        // Generate 6 digit angka acak
        $id = rand(100000, 999999);
        $cek = mysqli_query($conn, "SELECT id_pembeli FROM pembeli WHERE id_pembeli='$id'");
    } while (mysqli_num_rows($cek) > 0);
    return $id;
}

/* ── CREATE ── */
if (isset($_POST['create'])) {
    $id = generatePembeliId($conn);
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    mysqli_query($conn, "INSERT INTO pembeli (id_pembeli, nama_pembeli) VALUES ('$id', '$nama')");
    header("Location: pembeli.php?notif=created"); exit;
}

/* ── DELETE ── */
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    mysqli_query($conn, "DELETE FROM pembeli WHERE id_pembeli='$id'");
    header("Location: pembeli.php?notif=deleted"); exit;
}

$total = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM pembeli"))['c'] ?? 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pembeli — Toko Laris</title>
<link rel="stylesheet" href="style.css">
<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>

<?php include 'topbar.php'; ?>

<div class="page-wrap">
    <div class="page-hero">
        <div class="page-hero-content">
            <h2><i class="fa-solid fa-users" style="color:white;"></i> Data Pembeli</h2>
            <p>Kelola data pelanggan dan pembeli toko Anda</p>
        </div>
    </div>

    <div class="stats-row">
        <div class="stat-card green">
            <div class="stat-icon"><i class="fa-solid fa-users" style="color:green;"></i></div>
            <div class="stat-info">
                <div class="val"><?= $total ?></div>
                <div class="lbl">Total Pembeli</div>
            </div>
        </div>
    </div>

    <div class="content" style="margin-top:24px;">
        <?php if (isset($_GET['notif'])): ?>
        <div class="alert <?= $_GET['notif']==='deleted' ? 'alert-danger' : 'alert-success' ?>">
            <?= $_GET['notif']==='created' ? '<i class="fa-solid fa-square-check" style="color:green;"></i> Pembeli berhasil ditambahkan!' : '<i class="fa-solid fa-trash-can" style="color:black;"></i> Pembeli berhasil dihapus.' ?>
        </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-head">
                <div class="card-head-left">
                    <div class="card-head-icon"><i class="fa-solid fa-users" style="color:white;"></i></div>
                    <div>
                        <h3>Daftar Pembeli</h3>
                        <p><?= $total ?> pembeli terdaftar</p>
                    </div>
                </div>
                <button class="btn btn-red" onclick="openModal('modal-tambah')">
                    <i class="fa-solid fa-square-plus" style="color:orange;"></i> Tambah Pembeli
                </button>
            </div>

            <div class="card-body card-body-np">
                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>ID</th>
                                <th>Nama Pembeli</th>
                                <th style="text-align:center;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        $data = mysqli_query($conn,"SELECT * FROM pembeli ORDER BY nama_pembeli");
                        $no   = 1;
                        if ($data && mysqli_num_rows($data) > 0):
                            while ($d = mysqli_fetch_assoc($data)):
                        ?>
                            <tr>
                                <td style="color:var(--g4);font-size:12px;"><?= $no++ ?></td>
                                <td class="td-kode">#<?= $d['id_pembeli'] ?></td>
                                <td>
                                    <div style="display:flex;align-items:center;gap:10px;">
                                        <div style="width:36px;height:36px;border-radius:50%;background:var(--g1);
                                            display:flex;align-items:center;justify-content:center;
                                            font-weight:800;color:var(--green);font-size:14px;">
                                            <?= strtoupper(substr($d['nama_pembeli'],0,1)) ?>
                                        </div>
                                        <strong><?= htmlspecialchars($d['nama_pembeli']) ?></strong>
                                    </div>
                                </td>
                                <td style="text-align:center;">
                                    <div class="aksi" style="justify-content:center;">
                                        <a href="?delete=<?= $d['id_pembeli'] ?>"
                                           onclick="return confirm('Hapus pembeli ini?')"
                                           class="aksi-btn aksi-hapus"><i class="fa-solid fa-trash-can" style="color:black;"></i> Hapus</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile;
                        else: ?>
                            <tr><td colspan="4">
                                <div class="empty-state">
                                    <div class="empty-icon"><i class="fa-solid fa-users" style="font-size:48px;"></i></div>
                                    <h4>Belum ada pembeli</h4>
                                    <p>Tambahkan data pembeli terlebih dahulu.</p>
                                </div>
                            </td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <footer class="site-footer">
        &copy; <?= date('Y') ?> <strong>Toko Laris</strong>
    </footer>
</div>

<!-- MODAL -->
<div class="modal-overlay" id="modal-tambah">
    <div class="modal-box">
        <div class="modal-head">
            <h3><i class="fa-solid fa-users" style="color:white;"></i> Tambah Pembeli Baru</h3>
            <button class="modal-close" onclick="closeModal('modal-tambah')"><i class="fa-solid fa-x" style="color:black;"></i></button>
        </div>
        <div class="modal-body">
            <form method="POST">
                <div class="form-group">
                    <label>ID Pembeli <span style="color:var(--g4);font-weight:400;">(Otomatis)</span></label>
                    <div class="form-ctrl" style="background:var(--g1);font-family:'Nunito',monospace;font-weight:700;color:var(--r6);display:flex;align-items:center;gap:8px;">
                        <i class="fa-solid fa-lock" style="color:var(--g4);font-size:12px;"></i>
                        <?= generatePembeliId($conn) ?>
                    </div>
                    <div style="font-size:11px;color:var(--g4);margin-top:4px;">
                        <i class="fa-solid fa-wand-magic-sparkles"></i> ID digenerate otomatis oleh sistem
                    </div>
                </div>
                <div class="form-group">
                    <label>Nama Pembeli <span>*</span></label>
                    <input class="form-ctrl" name="nama" placeholder="Nama lengkap pembeli" required>
                </div>
                <div class="form-footer">
                    <button type="button" class="btn btn-ghost" onclick="closeModal('modal-tambah')">Batal</button>
                    <button name="create" class="btn btn-red"><i class="fa-solid fa-floppy-disk" style="color:green;"></i> Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openModal(id) {
    document.getElementById(id).classList.add('open');
}
function closeModal(id) {
    document.getElementById(id).classList.remove('open');
}
document.querySelectorAll('.modal-overlay').forEach(el => {
    el.addEventListener('click', function(e) {
        if (e.target === this) this.classList.remove('open');
    });
});
</script>
</body>
</html>