<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Staff</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="stylelogin.css">
  
<base target="_blank">
</head>
<body>

    <!-- Animated Background Particles -->
    <ul class="particles">
        <li class="particle"></li>
        <li class="particle"></li>
        <li class="particle"></li>
        <li class="particle"></li>
        <li class="particle"></li>
        <li class="particle"></li>
        <li class="particle"></li>
        <li class="particle"></li>
        <li class="particle"></li>
        <li class="particle"></li>
    </ul>

    <div class="login-box" id="loginBox">
        <div class="logo-container">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTEy1aCcW5My6rkbHg2Z6OU6ZsxqMxKF3V1xg&s" alt="TOKO">
        </div>
        <h2>Login Staff</h2>
        <p class="subtitle">Silakan masuk untuk melanjutkan</p>

        <form id="formLogin">
            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="text" id="username" placeholder="Username" required autocomplete="username">
            </div>

            <div class="input-group">
                <i class="fas fa-lock"></i>
                <input type="password" id="password" placeholder="Password" required autocomplete="current-password">
            </div>

            <div class="opsi">
                <label>
                    <input type="checkbox" id="remember">
                    Ingat Saya
                </label>
            </div>

            <button type="submit" id="loginBtn">
                <span class="spinner"></span>
                <span class="btn-text">Login</span>
            </button>
        </form>

        <p class="footer-text">
            <i class="fas fa-heart"></i> Selamat Bekerja
        </p>
    </div>

    <script>
        document.getElementById("formLogin").addEventListener("submit", function(e) {
            e.preventDefault();

            const loginBox = document.getElementById("loginBox");
            const loginBtn = document.getElementById("loginBtn");
            const btnText = loginBtn.querySelector(".btn-text");

            let user = document.getElementById("username").value.trim();
            let pass = document.getElementById("password").value;

            // Loading state
            loginBtn.classList.add("loading");
            btnText.textContent = "Memverifikasi...";
            loginBtn.disabled = true;

            // Simulate network delay for better UX
            setTimeout(function() {
                loginBtn.classList.remove("loading");
                btnText.textContent = "Login";
                loginBtn.disabled = false;

                const validUsers = ["naila", "herlambang", "arvin", "rasyid", "gamalita", "faiz"];

                if (validUsers.includes(user) && pass === "123") {
                    // Success animation
                    loginBox.classList.add("success-pulse");
                    setTimeout(() => {
                        window.location.href = "index.php";
                    }, 600);
                } else {
                    // Shake animation for error
                    loginBox.classList.add("shake");
                    setTimeout(() => {
                        loginBox.classList.remove("shake");
                    }, 500);

                    alert("Username atau Password Salah");
                    document.getElementById("password").value = "";
                    document.getElementById("password").focus();
                }
            }, 800);
        });
    </script>

</body>
</html>